# Lab 2
Homework for Web App Dev course

#### Task 1, 2, 3, 4, 5, 6 and 7
Done